package com.innopia.bist.util;

public enum Status {
	ON,
	OFF
}
