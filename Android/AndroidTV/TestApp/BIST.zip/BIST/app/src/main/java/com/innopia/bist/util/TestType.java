package com.innopia.bist.util;

public enum TestType {
	WIFI,
	BLUETOOTH,
	ETHERNET,
	CPU,
	MEMORY,
	VIDEO,
	HDMI,
	USB,
	RCU
}
